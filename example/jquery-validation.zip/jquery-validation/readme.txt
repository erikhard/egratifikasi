-= Membuat Validasi Form dengan JQuery Validation =-

Dibuat oleh	: Achmad Solichin
Situs 		: http://achmatim.net
Tanggal 	: 22 Mei 2012

Validasi form merupakan hal yang sangat penting untuk dilakukan. Beberapa alasannya antara lain untuk membatasi data masukan yang diinput oleh user, menjaga standarisasi data masukan, menjamin keamanan aplikasi dan meningkatkan kenyamanan pengguna. Dari sisi letaknya, validasi dapat dibagi menjadi dua, yaitu validasi di sisi server dan validasi di sisi client. Validasi di sisi server biasanya dilakukan setelah form di-submit (dikirim) dan menggunakan bahasa pemrograman sisi server seperti PHP, JSP dan ASP. Sedangkan validasi di sisi client dapat dilakukan sebelum data dari form inputan dikirim ke server. Validasi di client umumnya dilakukan dengan Javascript dan atribut HTML. Pada tutorial jquery kali ini, akan dijelaskan step by step bagaimana melakukan validasi form di sisi client dengan menggunakan library javascript JQuery dan plugin JQuery Validation. Tutorial lengkap dapat dilihat di http://achmatim.net/2012/05/22/membuat-validasi-form-dengan-jquery-validation/

Dapatkan tutorial komputer lainnya dengan mengunjungi situs http://achmatim.net

Maju terus ilmu pengetahuan Indonesia!
