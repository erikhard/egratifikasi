<?php
if (isset($_POST['Submit'])) {
	echo "<pre>";
	print_r($_POST);
	echo "</pre>";
}
?>
